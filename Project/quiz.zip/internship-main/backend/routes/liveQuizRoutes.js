import express from "express"
import {
  createLiveQuizSession,
  getLiveQuizSession,
  getAdminLiveQuizSessions,
  deleteLiveQuizSession,
} from "../controllers/liveQuizController.js"
import adminMiddleware  from "../middleware/adminMiddleware.js"

const router = express.Router()

// Admin routes
router.post("/create", adminMiddleware, createLiveQuizSession)
router.get("/admin/sessions", adminMiddleware, getAdminLiveQuizSessions)
router.delete("/admin/sessions/:sessionId", adminMiddleware, deleteLiveQuizSession)

// Public routes
router.get("/:sessionId", getLiveQuizSession)

export default router
