import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";
import { updateLastActive } from "./middleware/auth.js"; // Optional: use if needed

// Import routes
import authRoutes from "./routes/authRoutes.js";
import adminRoutes from "./routes/adminAuth.js";
import questionRoutes from "./routes/questionRoutes.js";
import quizRoutes from "./routes/quizRoutes.js";
import submissionRoutes from "./routes/submissionRoutes.js";
import statsRoutes from "./routes/stats.js";
import studentRoutes from "./routes/students.js";
import liveQuizRoutes from "./routes/liveQuizRoutes.js";

// Import WebSocket handlers
import handleConnection from "./websocket/socketHandlers.js";

dotenv.config();
const app = express();
const server = createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
  cors: {
    origin: [
      "http://localhost:5173",
      process.env.ADMIN_FRONTEND_URL,
    ],
    methods: ["GET", "POST"],
    credentials: true,
  },
});

// Handle WebSocket connections
handleConnection(io);

// Middlewares
app.use(
  cors({
    origin: [
      "http://localhost:5173",
      process.env.ADMIN_FRONTEND_URL,
    ],
    credentials: true,
  })
);
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Inject io to req object for usage in routes
app.use((req, res, next) => {
  req.io = io;
  next();
});

// app.use(updateLastActive); // Optional: enable if you track activity

// Health check
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "UP",
    timestamp: new Date().toISOString(),
    websocket: "enabled",
  });
});

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/questions", questionRoutes);
app.use("/api/quiz", quizRoutes);
app.use("/api/submissions", submissionRoutes);
app.use("/api/stats", statsRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/live-quiz", liveQuizRoutes);

// Global error handler
app.use((err, req, res, next) => {
  console.error("Global error:", err);
  res.status(500).json({
    message: "Server error occurred",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// MongoDB connection and server start
const PORT = process.env.PORT || 5000;
mongoose
  .connect(process.env.MONGO_URI, {
    serverApi: { version: "1", strict: false, deprecationErrors: true },
    ssl: true,
  })
  .then(() => {
    console.log("✅ MongoDB Connected");
    server.listen(PORT, () => {
      console.log(`🚀 Unified backend server running on port ${PORT}`);
      console.log(`📡 WebSocket server ready`);
      console.log(`🛠️ Front-end URL: ${process.env.ADMIN_FRONTEND_URL || "http://localhost:5173"}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err);
    process.exit(1);
  });

// Graceful shutdown
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

function shutdown() {
  console.log("🔌 Closing server and database connections...");
  mongoose.connection.close(() => {
    console.log("🗃️ Database connection closed");
    process.exit(0);
  });
}

export default app;
