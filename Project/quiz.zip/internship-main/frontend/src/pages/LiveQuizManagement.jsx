"use client"

import { useState, useEffect } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Users, Clock, Share2, Trophy, Plus, Eye, Trash2 } from "lucide-react"
import { API_BASE_URL } from "../config"
import { io } from "socket.io-client"

export default function LiveQuizManagement() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [socket, setSocket] = useState(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [newSession, setNewSession] = useState({
    title: "",
    class: "",
    stream: "None",
    subject: "",
    topic: "",
    questionCount: "10",
    duration: "15",
  })

  const subjects = {
    5: ["Mathematics", "Science", "English", "Social Studies"],
    6: ["Mathematics", "Science", "English", "Social Studies"],
    7: ["Mathematics", "Science", "English", "Social Studies"],
    8: ["Mathematics", "Science", "English", "Social Studies"],
    9: ["Mathematics", "Science", "English", "Social Studies"],
    10: ["Mathematics", "Science", "English", "Social Studies"],
    11: ["Physics", "Chemistry", "Mathematics", "Biology"],
    12: ["Physics", "Chemistry", "Mathematics", "Biology"],
  }

  // Initialize socket connection
  useEffect(() => {
    const token = localStorage.getItem("adminToken")
    if (!token) return

    const newSocket = io(API_BASE_URL, {
      auth: { token },
    })

    newSocket.on("connect", () => {
      console.log("Connected to server")
    })

    newSocket.on("participant-joined", (data) => {
      toast({
        title: "New Participant",
        description: data.message,
      })
      queryClient.invalidateQueries(["admin-live-sessions"])
    })

    newSocket.on("error", (data) => {
      toast({
        title: "Error",
        description: data.message,
        variant: "destructive",
      })
    })

    setSocket(newSocket)

    return () => {
      newSocket.disconnect()
    }
  }, [toast, queryClient])

  // Fetch admin's live quiz sessions
  const { data: sessions = [], refetch } = useQuery({
    queryKey: ["admin-live-sessions"],
    queryFn: async () => {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/live-quiz/admin/sessions`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) throw new Error("Failed to fetch sessions")
      const data = await response.json()
      return data.sessions
    },
  })

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData) => {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/live-quiz/create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(sessionData),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Failed to create session")
      }
      return response.json()
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Live quiz session created successfully",
      })
      setShowCreateModal(false)
      setNewSession({
        title: "",
        class: "",
        stream: "None",
        subject: "",
        topic: "",
        questionCount: "10",
        duration: "15",
      })
      refetch()
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    },
  })

  // Delete session mutation
  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId) => {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/live-quiz/admin/sessions/${sessionId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) throw new Error("Failed to delete session")
      return response.json()
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Session deleted successfully",
      })
      refetch()
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    },
  })

  const createSession = () => {
    if (!newSession.title || !newSession.class || !newSession.subject) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    createSessionMutation.mutate(newSession)
  }

  const copyShareLink = (sessionId) => {
    const link = `${window.location.origin.replace("5174", "5173")}/live-quiz/${sessionId}`
    navigator.clipboard.writeText(link)
    toast({
      title: "Success",
      description: "Share link copied to clipboard",
    })
  }

  const deleteSession = (sessionId) => {
    if (window.confirm("Are you sure you want to delete this session?")) {
      deleteSessionMutation.mutate(sessionId)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "waiting":
        return "bg-yellow-100 text-yellow-800"
      case "active":
        return "bg-green-100 text-green-800"
      case "paused":
        return "bg-orange-100 text-orange-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Live Quiz Management</h1>
          <p className="text-gray-600 mt-2">Create and manage real-time quiz sessions</p>
        </div>

        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Live Quiz
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md bg-white">
            <DialogHeader>
              <DialogTitle>Create New Live Quiz Session</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Quiz Title</Label>
                <Input
                  id="title"
                  value={newSession.title}
                  onChange={(e) => setNewSession({ ...newSession, title: e.target.value })}
                  placeholder="Enter quiz title"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="class">Class</Label>
                  <Select
                    value={newSession.class}
                    onValueChange={(value) => setNewSession({ ...newSession, class: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {[5, 6, 7, 8, 9, 10, 11, 12].map((cls) => (
                        <SelectItem key={cls} value={cls.toString()}>
                          Class {cls}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {Number.parseInt(newSession.class) >= 11 && (
                  <div>
                    <Label htmlFor="stream">Stream</Label>
                    <Select
                      value={newSession.stream}
                      onValueChange={(value) => setNewSession({ ...newSession, stream: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select stream" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="PCM">PCM</SelectItem>
                        <SelectItem value="PCB">PCB</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="subject">Subject</Label>
                <Select
                  value={newSession.subject}
                  onValueChange={(value) => setNewSession({ ...newSession, subject: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    {subjects[Number.parseInt(newSession.class)]?.map((subject) => (
                      <SelectItem key={subject} value={subject}>
                        {subject}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="topic">Topic (Optional)</Label>
                <Input
                  id="topic"
                  value={newSession.topic}
                  onChange={(e) => setNewSession({ ...newSession, topic: e.target.value })}
                  placeholder="Enter topic"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="questionCount">Questions</Label>
                  <Select
                    value={newSession.questionCount}
                    onValueChange={(value) => setNewSession({ ...newSession, questionCount: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {[5, 10, 15, 20, 25].map((count) => (
                        <SelectItem key={count} value={count.toString()}>
                          {count} Questions
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="duration">Duration</Label>
                  <Select
                    value={newSession.duration}
                    onValueChange={(value) => setNewSession({ ...newSession, duration: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {[10, 15, 20, 30, 45].map((duration) => (
                        <SelectItem key={duration} value={duration.toString()}>
                          {duration} Minutes
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={createSession}
                disabled={createSessionMutation.isPending}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {createSessionMutation.isPending ? "Creating..." : "Create Quiz Session"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6">
        {sessions.length === 0 ? (
          <Card className="p-8 text-center">
            <div className="text-gray-500">
              <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium mb-2">No Live Quiz Sessions</h3>
              <p className="text-sm">Create your first live quiz session to get started</p>
            </div>
          </Card>
        ) : (
          sessions.map((session) => (
            <Card key={session._id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{session.title}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span>Class {session.class}</span>
                    {session.stream !== "None" && <span>{session.stream}</span>}
                    <span>{session.subject}</span>
                    {session.topic && <span>• {session.topic}</span>}
                  </div>
                  <div className="mt-2">
                    <span className="text-sm text-gray-500">Share Code: </span>
                    <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">{session.shareCode}</span>
                  </div>
                </div>

                <Badge className={getStatusColor(session.status)}>
                  {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span className="text-sm">{session.participants.length} Participants</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-green-600" />
                  <span className="text-sm">
                    Question {session.currentQuestionIndex + 1} of {session.questions.length}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Trophy className="w-4 h-4 text-purple-600" />
                  <span className="text-sm">Created {new Date(session.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button onClick={() => copyShareLink(session._id)} variant="outline" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Link
                </Button>

                <Button
                  onClick={() => window.open(`/admin/live-quiz-monitor/${session._id}`, "_blank")}
                  variant="outline"
                  size="sm"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Monitor
                </Button>

                <Button
                  onClick={() => deleteSession(session._id)}
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700"
                  disabled={deleteSessionMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
