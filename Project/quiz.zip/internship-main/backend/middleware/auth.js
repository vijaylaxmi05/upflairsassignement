import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Admin from '../models/Admin.js';

export const authenticate = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    let decoded;

    // Try verifying with student secret
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded._id).select('-password');
      req.user.role = 'student';
    } catch (studentErr) {
      // Try verifying with admin secret
      try {
        decoded = jwt.verify(token, process.env.JWT_SECRET_ADMIN);
        req.user = await Admin.findById(decoded._id).select('-password');
        req.user.role = 'admin';
      } catch (adminErr) {
        return res.status(401).json({ message: 'Invalid token' });
      }
    }

    if (!req.user) {
      return res.status(401).json({ message: 'User not found' });
    }

    next();
  } catch (err) {
    console.error("Auth error:", err);
    res.status(401).json({ message: 'Invalid token' });
  }
};


export const isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Access denied. Admin privileges required' });
  }
};

export const isStudent = (req, res, next) => {
  if (req.user && req.user.role === 'student') {
    next();
  } else {
    res.status(403).json({ message: 'Access denied. Student privileges required' });
  }
};

export const updateLastActive = async (req, res, next) => {
  if (req.user) {
    try {
      await User.findByIdAndUpdate(req.user._id, { lastActive: new Date() });
    } catch (err) {
      console.error('Error updating last active:', err);
    }
  }
  next();
};