"use client"

import { useState, useEffect } from "react"
import { useParams } from "wouter"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { Play, Pause, SkipForward, Users, Trophy, Clock, CheckCircle, Share2, BarChart3 } from "lucide-react"
import { io } from "socket.io-client"
import { API_BASE_URL } from "../config"

export default function LiveQuizMonitor() {
  const { sessionId } = useParams()
  const { toast } = useToast()

  const [socket, setSocket] = useState(null)
  const [session, setSession] = useState(null)
  const [participants, setParticipants] = useState([])
  const [liveStats, setLiveStats] = useState({
    totalParticipants: 0,
    averageScore: 0,
    questionsAnswered: 0,
    totalQuestions: 0,
    topScore: 0,
  })
  const [recentActivity, setRecentActivity] = useState([])

  useEffect(() => {
    const token = localStorage.getItem("adminToken")
    if (!token) return

    // Initialize socket connection
    const newSocket = io(API_BASE_URL, {
      auth: { token },
    })

    newSocket.on("connect", () => {
      console.log("Connected to server")
      newSocket.emit("join-live-quiz-admin", { sessionId })
    })

    newSocket.on("session-state", (data) => {
      setSession(data.session)
      setParticipants(data.session.participants)
      updateLiveStats(data.session)
    })

    newSocket.on("participant-joined", (data) => {
      toast({
        title: "New Participant",
        description: data.message,
      })
      setRecentActivity((prev) => [
        {
          type: "join",
          message: data.message,
          timestamp: data.timestamp || new Date(),
        },
        ...prev.slice(0, 9),
      ])
    })

    newSocket.on("quiz-started", (data) => {
      toast({
        title: "Quiz Started",
        description: data.message,
      })
      setRecentActivity((prev) => [
        {
          type: "start",
          message: data.message,
          timestamp: new Date(),
        },
        ...prev.slice(0, 9),
      ])
    })

    newSocket.on("next-question-sent", (data) => {
      toast({
        title: "Next Question",
        description: `Moved to question ${data.questionIndex + 1}`,
      })
      setRecentActivity((prev) => [
        {
          type: "question",
          message: `Question ${data.questionIndex + 1} sent`,
          timestamp: new Date(),
        },
        ...prev.slice(0, 9),
      ])
    })

    newSocket.on("quiz-completed", (data) => {
      toast({
        title: "Quiz Completed",
        description: data.message,
      })
      setRecentActivity((prev) => [
        {
          type: "complete",
          message: data.message,
          timestamp: new Date(),
        },
        ...prev.slice(0, 9),
      ])
    })

    newSocket.on("quiz-status-changed", (data) => {
      toast({
        title: "Status Changed",
        description: data.message,
      })
    })

    newSocket.on("live-stats-update", (data) => {
      setLiveStats(data)
    })

    newSocket.on("error", (data) => {
      toast({
        title: "Error",
        description: data.message,
        variant: "destructive",
      })
    })

    setSocket(newSocket)

    return () => {
      newSocket.disconnect()
    }
  }, [sessionId, toast])

  const updateLiveStats = (sessionData) => {
    const stats = {
      totalParticipants: sessionData.participants.length,
      averageScore:
        sessionData.participants.length > 0
          ? Math.round(sessionData.participants.reduce((sum, p) => sum + p.score, 0) / sessionData.participants.length)
          : 0,
      questionsAnswered: sessionData.currentQuestionIndex + 1,
      totalQuestions: sessionData.questions.length,
      topScore: Math.max(...sessionData.participants.map((p) => p.score), 0),
    }
    setLiveStats(stats)
  }

  const startQuiz = () => {
    if (socket) {
      socket.emit("start-quiz", { sessionId })
    }
  }

  const nextQuestion = () => {
    if (socket) {
      socket.emit("next-question", { sessionId })
    }
  }

  const togglePause = () => {
    if (socket) {
      socket.emit("toggle-quiz-pause", { sessionId })
    }
  }

  const getLiveStats = () => {
    if (socket) {
      socket.emit("get-live-stats", { sessionId })
    }
  }

  const simulateStudentJoin = () => {
    if (socket) {
      const studentName = `Test Student ${Math.floor(Math.random() * 100)}`
      socket.emit("simulate-student-join", { sessionId, studentName })
    }
  }

  const copyShareLink = () => {
    const link = `${window.location.origin.replace("5174", "5173")}/live-quiz/${sessionId}`
    navigator.clipboard.writeText(link)
    toast({
      title: "Success",
      description: "Share link copied to clipboard",
    })
  }

  if (!session) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading quiz session...</p>
        </div>
      </div>
    )
  }

  const progress =
    session.questions.length > 0 ? ((session.currentQuestionIndex + 1) / session.questions.length) * 100 : 0

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{session.title}</h1>
            <p className="text-gray-600 mt-1">Live Quiz Monitor</p>
          </div>
          <div className="flex space-x-2">
            <Button onClick={copyShareLink} variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              Share Link
            </Button>
            <Badge
              className={`px-3 py-1 ${
                session.status === "active"
                  ? "bg-green-100 text-green-800"
                  : session.status === "waiting"
                    ? "bg-yellow-100 text-yellow-800"
                    : session.status === "paused"
                      ? "bg-orange-100 text-orange-800"
                      : "bg-gray-100 text-gray-800"
              }`}
            >
              {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
            </Badge>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{liveStats.totalParticipants}</p>
                <p className="text-sm text-gray-600">Participants</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold">
                  {liveStats.questionsAnswered}/{liveStats.totalQuestions}
                </p>
                <p className="text-sm text-gray-600">Questions</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <Trophy className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{liveStats.topScore}</p>
                <p className="text-sm text-gray-600">Top Score</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">{liveStats.averageScore}</p>
                <p className="text-sm text-gray-600">Avg Score</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-indigo-600" />
              <div>
                <p className="text-2xl font-bold">{Math.round(progress)}%</p>
                <p className="text-sm text-gray-600">Complete</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Quiz Progress</span>
            <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>

        {/* Control Buttons */}
        <div className="flex space-x-2 mb-6">
          {session.status === "waiting" && (
            <Button onClick={startQuiz} className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-2" />
              Start Quiz
            </Button>
          )}

          {session.status === "active" && (
            <>
              <Button onClick={togglePause} variant="outline">
                <Pause className="w-4 h-4 mr-2" />
                Pause Quiz
              </Button>
              <Button onClick={nextQuestion} className="bg-blue-600 hover:bg-blue-700">
                <SkipForward className="w-4 h-4 mr-2" />
                Next Question
              </Button>
            </>
          )}

          {session.status === "paused" && (
            <Button onClick={togglePause} className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-2" />
              Resume Quiz
            </Button>
          )}

          <Button onClick={getLiveStats} variant="outline">
            <BarChart3 className="w-4 h-4 mr-2" />
            Refresh Stats
          </Button>

          <Button onClick={simulateStudentJoin} variant="outline" className="bg-gray-100">
            <Users className="w-4 h-4 mr-2" />
            Test Join
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Participants List */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Participants ({participants.length})</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {participants.map((participant, index) => (
              <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{participant.name}</p>
                  <p className="text-sm text-gray-600">Joined {new Date(participant.joinedAt).toLocaleTimeString()}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">{participant.score}</p>
                  <p className="text-sm text-gray-600">{participant.answersCount} answers</p>
                </div>
              </div>
            ))}
            {participants.length === 0 && (
              <p className="text-center text-gray-500 py-8">No participants yet. Share the quiz link to get started!</p>
            )}
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  {activity.type === "join" && <Users className="w-4 h-4 text-blue-600" />}
                  {activity.type === "start" && <Play className="w-4 h-4 text-green-600" />}
                  {activity.type === "question" && <Clock className="w-4 h-4 text-purple-600" />}
                  {activity.type === "complete" && <Trophy className="w-4 h-4 text-orange-600" />}
                  <div>
                    <p className="text-sm font-medium">{activity.message}</p>
                    <p className="text-xs text-gray-500">{new Date(activity.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              </div>
            ))}
            {recentActivity.length === 0 && <p className="text-center text-gray-500 py-8">No recent activity</p>}
          </div>
        </Card>
      </div>
    </div>
  )
}
