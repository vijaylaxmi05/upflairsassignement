import LiveQuizSession from "../models/LiveQuizSession.js"
import Admin from "../models/Admin.js"
import jwt from "jsonwebtoken"

const authenticateSocket = async (socket, next) => {
  try {
    const token = socket.handshake.auth.token
    if (!token) {
      return next(new Error("Authentication error"))
    }

    // Try admin token first
    const decoded = jwt.verify(token, process.env.JWT_SECRET_ADMIN || process.env.JWT_SECRET)
    const admin = await Admin.findById(decoded.id)

    if (!admin) {
      return next(new Error("Admin not found"))
    }

    socket.adminId = admin._id.toString()
    socket.adminName = admin.name
    next()
  } catch (error) {
    next(new Error("Authentication error"))
  }
}

const handleConnection = (io) => {
  io.use(authenticateSocket)

  io.on("connection", (socket) => {
    console.log(`Admin connected: ${socket.adminName}`)

    // Admin joins live quiz session for monitoring
    socket.on("join-live-quiz-admin", async (data) => {
      try {
        const { sessionId } = data
        const session = await LiveQuizSession.findById(sessionId)
          .populate("questions")
          .populate("participants.student", "name email")

        if (!session) {
          socket.emit("error", { message: "Quiz session not found" })
          return
        }

        socket.join(`admin-${sessionId}`)
        socket.currentSession = sessionId

        // Send current session state to admin
        socket.emit("session-state", {
          session: {
            _id: session._id,
            title: session.title,
            status: session.status,
            currentQuestionIndex: session.currentQuestionIndex,
            participantCount: session.participants.length,
            participants: session.participants.map((p) => ({
              name: p.student?.name || "Unknown",
              joinedAt: p.joinedAt,
              score: p.score,
              answersCount: p.answers.length,
            })),
            questions: session.questions,
          },
        })
      } catch (error) {
        console.error("Error joining admin session:", error)
        socket.emit("error", { message: "Failed to join session" })
      }
    })

    // Start quiz (admin only)
    socket.on("start-quiz", async (data) => {
      try {
        const { sessionId } = data
        const session = await LiveQuizSession.findById(sessionId).populate("questions")

        if (!session) {
          socket.emit("error", { message: "Quiz session not found" })
          return
        }

        session.status = "active"
        session.startedAt = new Date()
        session.currentQuestionIndex = 0
        await session.save()

        // Notify admin that quiz started
        socket.emit("quiz-started", {
          message: "Quiz started successfully!",
          currentQuestionIndex: 0,
          totalQuestions: session.questions.length,
        })

        // Broadcast to all admins monitoring this session
        io.to(`admin-${sessionId}`).emit("quiz-status-update", {
          status: "active",
          currentQuestionIndex: 0,
          message: "Quiz has started",
        })
      } catch (error) {
        console.error("Error starting quiz:", error)
        socket.emit("error", { message: "Failed to start quiz" })
      }
    })

    // Next question (admin only)
    socket.on("next-question", async (data) => {
      try {
        const { sessionId } = data
        const session = await LiveQuizSession.findById(sessionId).populate("questions")

        if (!session) {
          socket.emit("error", { message: "Quiz session not found" })
          return
        }

        if (session.currentQuestionIndex < session.questions.length - 1) {
          session.currentQuestionIndex += 1
          await session.save()

          // Notify admin about next question
          socket.emit("next-question-sent", {
            questionIndex: session.currentQuestionIndex,
            totalQuestions: session.questions.length,
            question: session.questions[session.currentQuestionIndex],
          })

          // Broadcast to all admins
          io.to(`admin-${sessionId}`).emit("quiz-status-update", {
            status: "active",
            currentQuestionIndex: session.currentQuestionIndex,
            message: `Moved to question ${session.currentQuestionIndex + 1}`,
          })
        } else {
          // Quiz completed
          session.status = "completed"
          session.endedAt = new Date()
          await session.save()

          const finalResults = session.participants.map((p) => ({
            name: p.student?.name || "Unknown",
            score: p.score,
            totalAnswers: p.answers.length,
            percentage: Math.round((p.score / session.questions.length) * 100),
          }))

          socket.emit("quiz-completed", {
            message: "Quiz completed!",
            results: finalResults,
          })

          io.to(`admin-${sessionId}`).emit("quiz-status-update", {
            status: "completed",
            message: "Quiz has been completed",
            results: finalResults,
          })
        }
      } catch (error) {
        console.error("Error moving to next question:", error)
        socket.emit("error", { message: "Failed to move to next question" })
      }
    })

    // Pause/Resume quiz (admin only)
    socket.on("toggle-quiz-pause", async (data) => {
      try {
        const { sessionId } = data
        const session = await LiveQuizSession.findById(sessionId)

        if (!session) {
          socket.emit("error", { message: "Quiz session not found" })
          return
        }

        session.status = session.status === "active" ? "paused" : "active"
        await session.save()

        const message = session.status === "paused" ? "Quiz paused" : "Quiz resumed"

        socket.emit("quiz-status-changed", {
          status: session.status,
          message,
        })

        io.to(`admin-${sessionId}`).emit("quiz-status-update", {
          status: session.status,
          message,
        })
      } catch (error) {
        console.error("Error toggling quiz pause:", error)
        socket.emit("error", { message: "Failed to toggle quiz pause" })
      }
    })

    // Get live statistics
    socket.on("get-live-stats", async (data) => {
      try {
        const { sessionId } = data
        const session = await LiveQuizSession.findById(sessionId).populate("participants.student", "name")

        if (!session) {
          socket.emit("error", { message: "Quiz session not found" })
          return
        }

        const stats = {
          totalParticipants: session.participants.length,
          averageScore:
            session.participants.length > 0
              ? Math.round(session.participants.reduce((sum, p) => sum + p.score, 0) / session.participants.length)
              : 0,
          questionsAnswered: session.currentQuestionIndex + 1,
          totalQuestions: session.questions.length,
          topScore: Math.max(...session.participants.map((p) => p.score), 0),
        }

        socket.emit("live-stats-update", stats)
      } catch (error) {
        console.error("Error getting live stats:", error)
        socket.emit("error", { message: "Failed to get live stats" })
      }
    })

    // Simulate student joining (for testing)
    socket.on("simulate-student-join", async (data) => {
      try {
        const { sessionId, studentName } = data

        // Notify admin about new participant
        socket.emit("participant-joined", {
          studentName: studentName || "Test Student",
          message: `${studentName || "Test Student"} joined the quiz`,
          timestamp: new Date(),
        })
      } catch (error) {
        console.error("Error simulating student join:", error)
      }
    })

    // Handle disconnection
    socket.on("disconnect", () => {
      console.log(`Admin disconnected: ${socket.adminName}`)
    })
  })
}

export default handleConnection
