import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FiUser, FiMail, FiLock } from "react-icons/fi";
import { Link } from "wouter";

const AdminForm = ({ type, formData, setFormData, handleSubmit }) => {
  const isRegister = type === "register";

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-100 to-blue-200 px-4">
      <Card className="w-full max-w-lg shadow-2xl rounded-3xl bg-white">
        <CardContent className="p-8">
          <h2 className="text-3xl font-semibold text-center mb-6 text-blue-700">
            {isRegister ? "Admin Register" : "Admin Login"}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            {isRegister && (
              <>
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    value={formData.bio}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="experience">Years of Experience</Label>
                  <Input
                    id="experience"
                    name="experience"
                    type="text"
                    value={formData.experience}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="studentsTaught">Students Taught</Label>
                  <Input
                    id="studentsTaught"
                    name="studentsTaught"
                    type="number"
                    value={formData.studentsTaught}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="subjects">Subjects (comma-separated)</Label>
                  <Input
                    id="subjects"
                    name="subjects"
                    type="text"
                    value={formData.subjects}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="achievements">
                    Achievements (comma-separated)
                  </Label>
                  <Input
                    id="achievements"
                    name="achievements"
                    type="text"
                    value={formData.achievements}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="certifications">
                    Certifications (comma-separated)
                  </Label>
                  <Input
                    id="certifications"
                    name="certifications"
                    type="text"
                    value={formData.certifications}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="profileImage">Profile Image URL</Label>
                  <Input
                    id="profileImage"
                    name="profileImage"
                    type="text"
                    value={formData.profileImage}
                    onChange={handleChange}
                  />
                </div>
              </>
            )}

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-xl text-md"
            >
              {isRegister ? "Create Account" : "Login"}
            </Button>
          </form>

          <div className="text-sm text-center mt-6 text-gray-600">
            {isRegister ? (
              <>
                Already have an account?{" "}
                <Link
                  href="/admin/login"
                  className="text-blue-600 hover:underline font-medium"
                >
                  Login
                </Link>
              </>
            ) : (
              <>
                Don't have an account?{" "}
                <Link
                  href="/admin/register"
                  className="text-blue-600 hover:underline font-medium"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminForm;
