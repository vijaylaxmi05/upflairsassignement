import { useState } from "react";
import DashboardNavbar from "../components/DashboardNavbar";
import EditProfileModal from "../components/EditProfileModal";
import { useUser } from "../context/UserContext";

const Profile = () => {
  const { userData } = useUser();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardNavbar />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Card */}
          <div className="bg-white rounded-lg shadow p-6 mb-8">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold">My Profile</h1>
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="px-4 py-2 bg-blue-500 text-white rounded-2xl flex items-center hover:bg-blue-600 transition-colors"
              >
                <i className="fas fa-edit mr-2"></i>
                Edit Profile
              </button>
            </div>

            <div className="md:flex">
              <div className="md:w-1/3 flex flex-col items-center mb-6 md:mb-0">
                <div className="w-32 h-32 rounded-full overflow-hidden mb-4">
                  <img
                    src={
                      userData?.profilePicture ||
                      `https://api.dicebear.com/8.x/bottts/svg?seed=${
                        userData?.email || "guest"
                      }`
                    }
                    alt="Profile Avatar"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h2 className="text-xl font-semibold">{userData?.name}</h2>
                <p className="text-gray-600">
                  Class {userData?.class} - {userData?.stream}
                </p>
              </div>

              <div className="md:w-2/3 md:pl-8">
                <h3 className="text-xl font-semibold mb-4">
                  Personal Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Email Address
                    </label>
                    <div className="mt-1 p-2 bg-gray-100 rounded-md text-gray-700 cursor-not-allowed">
                      {userData?.email}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      School Name
                    </label>
                    <div className="mt-1 p-2 bg-gray-100 rounded-md text-gray-700 cursor-not-allowed">
                      {userData?.school || "Not provided"}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Roll Number
                    </label>
                    <div className="mt-1 p-2 bg-gray-100 rounded-md text-gray-700 cursor-not-allowed">
                      {userData?.rollNumber || "Not provided"}
                    </div>
                  </div>

                  {/* Class (disabled dropdown) */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Class
                    </label>
                    <div className="mt-1 flex">
                      <div className="relative w-full">
                        <select
                          disabled
                          value={userData?.class}
                          className="block w-full p-2 bg-gray-100 border border-gray-300 rounded-md appearance-none pr-8 text-gray-700 cursor-not-allowed"
                        >
                          <option>{`Class ${userData?.class}`}</option>
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                          <i className="fas fa-chevron-down"></i>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Stream (disabled dropdown) */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Stream
                    </label>
                    <div className="mt-1 flex">
                      <div className="relative w-full">
                        <select
                          disabled
                          value={userData?.stream}
                          className="block w-full p-2 bg-gray-100 border border-gray-300 rounded-md appearance-none pr-8 text-gray-700 cursor-not-allowed"
                        >
                          <option>{userData?.stream}</option>
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                          <i className="fas fa-chevron-down"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Motivational Quote Section */}
          <div className="bg-gradient-to-r from-blue-100 via-white to-blue-50 p-6 rounded-lg text-center shadow mb-8">
            <p className="text-lg italic text-gray-700">
              “The beautiful thing about learning is that nobody can take it
              away from you.”
            </p>
            <span className="mt-2 block font-semibold text-blue-700">
              — B.B. King
            </span>
          </div>

          {/* Badges Section */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-semibold mb-4">
              🏅 Achievements & Badges
            </h3>
            <div className="flex flex-wrap gap-6">
              <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg text-center shadow-sm w-36">
                <img
                  src="https://img.icons8.com/color/96/medal.png"
                  alt="Top Scorer Badge"
                  className="h-12 mx-auto"
                />
                <p className="mt-2 text-sm font-medium text-gray-700">
                  Top Scorer
                </p>
              </div>

              <div className="p-4 bg-green-50 border border-green-100 rounded-lg text-center shadow-sm w-36">
                <img
                  src="https://img.icons8.com/color/96/trophy.png"
                  alt="Quiz Master Badge"
                  className="h-12 mx-auto"
                />
                <p className="mt-2 text-sm font-medium text-gray-700">
                  Quiz Master
                </p>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-100 rounded-lg text-center shadow-sm w-36">
                <img
                  src="https://img.icons8.com/color/96/star.png"
                  alt="Consistent Learner Badge"
                  className="h-12 mx-auto"
                />
                <p className="mt-2 text-sm font-medium text-gray-700">
                  Consistent Learner
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
    </div>
  );
};

export default Profile;
