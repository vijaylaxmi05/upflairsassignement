import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useUser } from '../context/UserContext';

const Navbar = () => {
  const { userData, isAuthenticated, signOut } = useUser();
  const [location, setLocation] = useLocation();
  const [showDropdown, setShowDropdown] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const handleSignOut = () => {
    signOut();
    setShowDropdown(false);
    setShowMobileMenu(false);
    setLocation('/');
  };

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const toggleMobileMenu = () => {
    setShowMobileMenu((prev) => !prev);
  };

  return (
    <nav className="relative flex items-center justify-between py-4 px-6 bg-white shadow-sm">
      {/* Logo */}
      <Link
        href="/"
        className="text-2xl font-bold text-blue-500 mr-8 transition-transform hover:scale-105 duration-300"
        onClick={() => {
          setShowDropdown(false);
          setShowMobileMenu(false);
        }}
      >
        Tinker Tutor
      </Link>

      {/* Desktop menu */}
      <div className="hidden md:flex items-center space-x-6">
        {isAuthenticated ? (
          <div className="relative">
            <button
              onClick={toggleDropdown}
              className="flex items-center focus:outline-none"
              aria-label="User menu"
            >
              <img
                src={`https://api.dicebear.com/8.x/bottts/svg?seed=${userData?.email || 'guest'}`}
                alt="Avatar"
                className="w-10 h-10 rounded-full border-2 border-blue-400 object-cover"
              />
            </button>

            {showDropdown && (
              <div className="absolute right-0 mt-2 w-48 py-2 bg-white rounded-md shadow-lg z-20">
                <Link
                  href="/dashboard"
                  className="block px-4 py-2 text-gray-800 hover:bg-blue-50"
                  onClick={() => setShowDropdown(false)}
                >
                  Dashboard
                </Link>
                <Link
                  href="/profile"
                  className="block px-4 py-2 text-gray-800 hover:bg-blue-50"
                  onClick={() => setShowDropdown(false)}
                >
                  Profile
                </Link>
                <button
                  onClick={handleSignOut}
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-blue-50"
                >
                  Sign Out
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            <Link
              href="/select-role"
              className="px-5 py-2 bg-purple-500 text-white rounded-xl font-medium hover:bg-purple-600 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              Sign In
            </Link>
            <Link
              href="/select-role"
              className="px-5 py-2 bg-purple-500 text-white rounded-xl font-medium hover:bg-purple-600 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              Sign Up
            </Link>
          </>
        )}
      </div>

      {/* Mobile Hamburger */}
      <button
        className="md:hidden flex items-center focus:outline-none focus:ring-2 focus:ring-blue-500 rounded"
        onClick={toggleMobileMenu}
        aria-label="Toggle mobile menu"
        aria-expanded={showMobileMenu}
      >
        {showMobileMenu ? (
          <svg
            className="w-6 h-6 text-blue-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg
            className="w-6 h-6 text-blue-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        )}
      </button>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="absolute top-full right-0 left-0 bg-white shadow-md rounded-b-md py-4 px-6 md:hidden z-30">
          {isAuthenticated ? (
            <>
              <Link
                href="/dashboard"
                className="block px-4 py-2 text-gray-800 hover:bg-blue-50 rounded mb-1"
                onClick={() => setShowMobileMenu(false)}
              >
                Dashboard
              </Link>
              <Link
                href="/profile"
                className="block px-4 py-2 text-gray-800 hover:bg-blue-50 rounded mb-1"
                onClick={() => setShowMobileMenu(false)}
              >
                Profile
              </Link>
              <button
                onClick={() => {
                  handleSignOut();
                  setShowMobileMenu(false);
                }}
                className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-blue-50 rounded"
              >
                Sign Out
              </button>
            </>
          ) : (
            <>
              <Link
                href="/select-role"
                className="block px-5 py-2 bg-purple-500 text-white rounded-xl font-medium hover:bg-purple-600 mb-2"
                onClick={() => setShowMobileMenu(false)}
              >
                Sign In
              </Link>
              <Link
                href="/select-role"
                className="block px-5 py-2 bg-purple-500 text-white rounded-xl font-medium hover:bg-purple-600"
                onClick={() => setShowMobileMenu(false)}
              >
                Sign Up
              </Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
