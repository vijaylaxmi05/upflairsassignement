import mongoose from "mongoose"

const liveQuizSessionSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    admin: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      required: true,
    },
    class: {
      type: Number,
      required: true,
      enum: [5, 6, 7, 8, 9, 10, 11, 12],
    },
    stream: {
      type: String,
      enum: ["PCM", "PCB", "None"],
      default: "None",
    },
    subject: {
      type: String,
      required: true,
    },
    topic: {
      type: String,
      default: "",
    },
    questions: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Question",
      },
    ],
    duration: {
      type: Number, // in minutes
      required: true,
    },
    status: {
      type: String,
      enum: ["waiting", "active", "paused", "completed"],
      default: "waiting",
    },
    participants: [
      {
        student: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        joinedAt: {
          type: Date,
          default: Date.now,
        },
        answers: [
          {
            questionIndex: Number,
            selectedAnswer: Number,
            answeredAt: Date,
            isCorrect: Boolean,
          },
        ],
        score: {
          type: Number,
          default: 0,
        },
        completedAt: Date,
      },
    ],
    currentQuestionIndex: {
      type: Number,
      default: 0,
    },
    startedAt: Date,
    endedAt: Date,
    shareCode: {
      type: String,
      unique: true,
    },
  },
  { timestamps: true },
)

// Generate unique share code before saving
liveQuizSessionSchema.pre("save", function (next) {
  if (!this.shareCode) {
    this.shareCode = Math.random().toString(36).substring(2, 8).toUpperCase()
  }
  next()
})

export default mongoose.model("LiveQuizSession", liveQuizSessionSchema)
