import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useUser } from '../context/UserContext';

const DashboardNavbar = () => {
  const { userData, signOut } = useUser();
  const [location, setLocation] = useLocation();
  const [showDropdown, setShowDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path) =>
    location === path
      ? 'bg-blue-600 text-white'
      : 'text-gray-800 hover:bg-blue-50';

  const handleSignOut = () => {
    signOut();
    setShowDropdown(false);
    setLocation('/');
  };

  const toggleDropdown = () => setShowDropdown(!showDropdown);
  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);

  return (
    <nav className="bg-white shadow-sm px-4 py-3 md:px-8">
      <div className="flex items-center justify-between">
        {/* Logo + Title */}
        <div className="flex items-center justify-between w-full md:w-auto">
          <Link
            href="/"
            className="text-xl font-bold text-blue-500 transition-transform hover:scale-105 duration-300"
          >
            Tinker Tutor
          </Link>

          {/* Hamburger Menu - visible on small screens */}
          <button
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMobileMenu}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              {mobileMenuOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              )}
            </svg>
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden md:flex space-x-2">
          {[
            { href: '/dashboard', label: 'Dashboard' },
            { href: '/quiz', label: 'Take Quiz' },
            { href: '/reports', label: 'Reports' },
            { href: '/profile', label: 'Profile' }
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`px-4 py-2 rounded-2xl font-medium transition-all duration-300 hover:-translate-y-1 ${isActive(item.href)}`}
            >
              {item.label}
            </Link>
          ))}
        </div>

        {/* Avatar and Dropdown */}
        <div className="relative ml-4">
          <button
            onClick={toggleDropdown}
            className="flex items-center focus:outline-none transition-transform hover:scale-110 duration-300"
          >
            <img
              src={`https://api.dicebear.com/8.x/bottts/svg?seed=${userData?.email || 'guest'}`}
              alt="Profile"
              className="w-10 h-10 rounded-full object-cover border-2 border-blue-400"
            />
          </button>

          {showDropdown && (
            <div className="absolute right-0 mt-2 w-48 py-2 bg-white rounded-md shadow-lg z-20">
              <Link
                href="/profile"
                className="block px-4 py-2 rounded-md text-gray-800 hover:bg-blue-50"
                onClick={() => setShowDropdown(false)}
              >
                My Profile
              </Link>
              <button
                onClick={handleSignOut}
                className="block w-full text-left px-4 py-2 rounded-md text-gray-800 hover:bg-blue-50"
              >
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-3 space-y-2">
          {[
            { href: '/dashboard', label: 'Dashboard' },
            { href: '/quiz', label: 'Take Quiz' },
            { href: '/reports', label: 'Reports' },
            { href: '/profile', label: 'Profile' }
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`block px-4 py-2 rounded-md font-medium ${isActive(item.href)}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
};

export default DashboardNavbar;
