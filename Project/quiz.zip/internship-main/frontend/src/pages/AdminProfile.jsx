import React, { useEffect, useState } from "react";
import API from "../lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  User,
  Edit3,
  Save,
  XCircle,
  Book,
  Award,
  GraduationCap,
  Users,
  Mail,
} from "lucide-react";

const AdminProfile = () => {
  const [admin, setAdmin] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await API.get("/profile", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
          },
        });
        setAdmin(res.data);
        setFormData(res.data);
      } catch (err) {
        alert("Error loading profile");
      }
    };
    fetchProfile();
  }, []);

  const handleUpdate = async () => {
    try {
      const res = await API.put("/profile", formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      });
      setAdmin(res.data);
      setEditMode(false);
    } catch (err) {
      alert("Update failed");
    }
  };

  if (!admin) return <div className="text-center mt-10">Loading...</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-10 space-y-8">
      {/* Profile Header */}
      <Card className="p-6 rounded-3xl shadow-lg hover:shadow-xl transition duration-300 bg-white flex flex-col md:flex-row items-center gap-6">
        <div className="w-28 h-28 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-4xl font-bold">
          <User className="w-10 h-10" />
        </div>
        <div className="flex-1 space-y-2">
          <h2 className="text-3xl font-bold text-gray-800">{admin.name}</h2>
          <p className="text-gray-500 flex items-center gap-2">
            <Mail className="w-4 h-4" /> {admin.email}
          </p>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="outline" className="text-sm">
              <Users className="w-4 h-4 mr-1" /> {admin.studentsTaught} Students
            </Badge>
            {admin.subjects?.map((subject, idx) => (
              <Badge key={idx} className="bg-blue-100 text-blue-800 text-sm">
                <Book className="w-3 h-3 mr-1" /> {subject}
              </Badge>
            ))}
          </div>
        </div>
        <div className="flex md:flex-col gap-2">
          <Button
            onClick={() => setEditMode(!editMode)}
            variant={editMode ? "ghost" : "secondary"}
            className={`transition-all duration-200 cursor-pointer ${
              editMode
                ? "text-red-600 hover:bg-red-100"
                : "text-blue-600 hover:bg-blue-100"
            }`}
          >
            {editMode ? (
              <>
                <XCircle className="w-4 h-4 mr-1 cursor-pointer" /> Cancel
              </>
            ) : (
              <>
                <Edit3 className="w-4 h-4 mr-1 cursor-pointer" /> Edit
              </>
            )}
          </Button>
          {editMode && (
            <Button
              onClick={handleUpdate}
              className="bg-green-600 hover:bg-green-700 text-white transition-all duration-200 cursor-pointer"
            >
              <Save className="w-4 h-4 mr-1 " /> Save
            </Button>
          )}
        </div>
      </Card>

      {/* Editable Form Section */}
      <Card className="p-8 rounded-3xl shadow-lg bg-white hover:shadow-xl transition duration-300 space-y-6">
        {/* Section Title */}
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-1">
            Basic Information
          </h3>
          <p className="text-sm text-gray-500">
            You can edit your teaching profile below.
          </p>
        </div>

        {/* Grid Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <Input
              className="focus:ring-2 focus:ring-blue-500"
              value={formData.name || ""}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              disabled={!editMode}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <Input
              className="bg-gray-100 cursor-not-allowed"
              value={formData.email || ""}
              disabled
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Students Taught
            </label>
            <Input
              type="number"
              className="focus:ring-2 focus:ring-blue-500"
              value={formData.studentsTaught || ""}
              onChange={(e) =>
                setFormData({ ...formData, studentsTaught: e.target.value })
              }
              disabled={!editMode}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subjects
            </label>
            <Input
              className="focus:ring-2 focus:ring-blue-500"
              placeholder="Comma-separated e.g. Math, Physics"
              value={formData.subjects?.join(", ") || ""}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  subjects: e.target.value.split(",").map((s) => s.trim()),
                })
              }
              disabled={!editMode}
            />
          </div>
        </div>

        {/* Text Areas Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Bio
              </label>
              <Textarea
                rows={3}
                className="focus:ring-2 focus:ring-blue-500"
                value={formData.bio || ""}
                onChange={(e) =>
                  setFormData({ ...formData, bio: e.target.value })
                }
                disabled={!editMode}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Experience
              </label>
              <Textarea
                rows={2}
                className="focus:ring-2 focus:ring-blue-500"
                value={formData.experience || ""}
                onChange={(e) =>
                  setFormData({ ...formData, experience: e.target.value })
                }
                disabled={!editMode}
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Achievements
              </label>
              <Textarea
                rows={3}
                className="focus:ring-2 focus:ring-blue-500"
                placeholder="Comma-separated"
                value={formData.achievements?.join(", ") || ""}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    achievements: e.target.value
                      .split(",")
                      .map((a) => a.trim()),
                  })
                }
                disabled={!editMode}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Certifications
              </label>
              <Textarea
                rows={3}
                className="focus:ring-2 focus:ring-blue-500"
                placeholder="Comma-separated"
                value={formData.certifications?.join(", ") || ""}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    certifications: e.target.value
                      .split(",")
                      .map((c) => c.trim()),
                  })
                }
                disabled={!editMode}
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Read-only Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Achievements */}
        <Card className="p-6 rounded-2xl shadow-md hover:shadow-lg transition bg-white border border-green-200">
          <div className="flex items-center mb-4">
            <div className="w-9 h-9 rounded-full bg-green-100 flex items-center justify-center mr-3">
              <Award className="w-5 h-5 text-green-700" />
            </div>
            <h4 className="text-lg font-semibold text-green-800">
              Achievements
            </h4>
          </div>
          {admin.achievements?.length ? (
            <ul className="list-disc list-inside text-sm text-green-800 space-y-1">
              {admin.achievements.map((a, i) => (
                <li key={i}>{a}</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 italic">
              No achievements listed.
            </p>
          )}
        </Card>

        {/* Certifications */}
        <Card className="p-6 rounded-2xl shadow-md hover:shadow-lg transition bg-white border border-yellow-200">
          <div className="flex items-center mb-4">
            <div className="w-9 h-9 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
              <GraduationCap className="w-5 h-5 text-yellow-700" />
            </div>
            <h4 className="text-lg font-semibold text-yellow-800">
              Certifications
            </h4>
          </div>
          {admin.certifications?.length ? (
            <ul className="list-disc list-inside text-sm text-yellow-800 space-y-1">
              {admin.certifications.map((c, i) => (
                <li key={i}>{c}</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 italic">
              No certifications listed.
            </p>
          )}
        </Card>
      </div>
    </div>
  );
};

export default AdminProfile;
