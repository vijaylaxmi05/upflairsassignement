import React from 'react';
import { useLocation } from 'wouter';

const LandingPage = () => {
  const [, setLocation] = useLocation();

  return (
    <div className="font-sans text-gray-800">
      {/* Navbar */}
      <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
        <div className="text-3xl font-bold text-blue-600">Tinker Tutor</div>
        <div className="space-x-4">
          <button onClick={() => setLocation('/admin/login')} className="px-4 py-2 border border-blue-600 text-blue-600 rounded hover:bg-blue-50">Login</button>
          <button onClick={() => setLocation('/admin/register')} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Sign Up</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="text-center py-20 bg-gradient-to-br from-blue-50 to-white">
        <h1 className="text-4xl md:text-8xl font-extrabold mb-6 text-blue-700">Admin Panel</h1>
        <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-xl mx-auto">
          Authorized for Admins only!
        </p>
      </section>

      {/* Features */}
      <section id="admin-tools" className="py-16 px-6 bg-white text-center">
  <h2 className="text-3xl font-bold mb-10 text-blue-700">Admin Dashboard Tools</h2>
  <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
    {[
      {
        title: 'Manage Users',
        icon: '👥',
        desc: 'View, edit, suspend, or delete student accounts and assign roles.',
      },
      {
        title: 'Add/Edit Quizzes',
        icon: '📝',
        desc: 'Create new quizzes, edit existing ones, or delete outdated ones.',
      },
      {
        title: 'Monitor Performance',
        icon: '📊',
        desc: 'Track performance metrics and generate class-wise reports.',
      },
      {
        title: 'Post Announcements',
        icon: '📢',
        desc: 'Send important updates or test notifications to all users.',
      },
      {
        title: 'Organize Classes',
        icon: '🏫',
        desc: 'Assign subjects, streams, and organize students by class.',
      },
      {
        title: 'Quiz Analytics',
        icon: '📈',
        desc: 'View stats on quiz attempts, scores, and engagement levels.',
      },
    ].map((tool) => (
      <div key={tool.title} className="p-6 border rounded-lg shadow hover:shadow-lg transition">
        <div className="text-5xl mb-4">{tool.icon}</div>
        <h3 className="text-xl font-semibold text-blue-600">{tool.title}</h3>
        <p className="text-gray-600 mt-2">{tool.desc}</p>
      </div>
    ))}
  </div>
</section>


      {/* About */}
      <section id="about" className="bg-blue-50 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">About Tinker Tutor</h2>
          <p className="text-lg text-gray-700">
            Tinker Tutor is on a mission to bring innovation, creativity, and technology into classrooms. With expert instructors and project-based learning, we make complex subjects accessible and enjoyable for school students.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-blue-600 text-white py-6 text-center">
        <p>&copy; {new Date().getFullYear()} Tinker Tutor. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
