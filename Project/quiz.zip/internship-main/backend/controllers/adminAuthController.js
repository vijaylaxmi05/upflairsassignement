import Admin from "../models/Admin.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();

const generateToken = (admin) =>
  jwt.sign({ _id: admin._id, role: "admin" }, process.env.JWT_SECRET_ADMIN, {
    expiresIn: "3d",
  });

export const registerAdmin = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      bio,
      experience,
      studentsTaught,
      subjects,
      achievements,
      certifications,
      profileImage,
    } = req.body;

    const existingAdmin = await Admin.findOne({ email });
    if (existingAdmin) return res.status(400).json({ message: 'Admin already exists' });

    const admin = new Admin({
      name,
      email,
      password, // pass plain password, pre-save hook will hash
      bio,
      experience,
      studentsTaught,
      subjects: subjects?.split(',').map(s => s.trim()),
      achievements: achievements?.split(',').map(a => a.trim()),
      certifications: certifications?.split(',').map(c => c.trim()),
      profileImage,
    });

    await admin.save();

    const token = generateToken(admin);
    res.status(201).json({ token, role: 'admin' });
  } catch (error) {
    console.error('[Register Admin Error]', error);
    res.status(500).json({ message: 'Server error' });
  }
};


export const loginAdmin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });

    const token = generateToken(admin);
    res.json({ token, role: "admin" });
  } catch (err) {
    res.status(500).json({ message: "Login error", error: err.message });
  }
};

export const getAdminProfile = async (req, res) => {
  try {
    const admin = await Admin.findById(req.user._id).select("-password");
    res.json(admin);
  } catch (err) {
    res.status(500).json({ message: "Failed to get profile" });
  }
};

export const updateAdminProfile = async (req, res) => {
  try {
    const updates = req.body;
    const admin = await Admin.findByIdAndUpdate(req.user._id, updates, {
      new: true,
    }).select("-password");
    res.json(admin);
  } catch (err) {
    res.status(500).json({ message: "Failed to update profile" });
  }
};
