// export const API_BASE_URL =
//   import.meta.env.VITE_REACT_APP_API_BASE_URL ||
//   "https://quiz-app-tinkd.onrender.com/api";
export const API_BASE_URL =
  import.meta.env.VITE_REACT_APP_API_BASE_URL ||
  "https://tinker-tutor.onrender.com/api";
