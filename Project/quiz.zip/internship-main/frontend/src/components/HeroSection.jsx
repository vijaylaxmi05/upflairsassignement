import { Link } from "wouter";
import FeatureCard from "./FeatureCard";

const HeroSection = () => {
  const features = [
    {
      icon: <i className="fas fa-graduation-cap text-blue-500 text-3xl"></i>,
      title: "Classes 5-12",
      description: "Comprehensive curriculum coverage for all major subjects.",
    },
    {
      icon: <i className="fas fa-flask text-green-500 text-3xl"></i>,
      title: "PCM/PCB Focus",
      description: "In-depth materials tailored for science stream aspirants.",
    },
    {
      icon: <i className="fas fa-chart-line text-yellow-400 text-3xl"></i>,
      title: "Track Progress",
      description: "Visual performance reports to help monitor your growth.",
    },
    {
      icon: <i className="fas fa-robot text-pink-400 text-3xl"></i>,
      title: "Robotics & AI",
      description:
        "Learn cutting-edge tech through fun projects and tutorials.",
    },
    {
      icon: <i className="fas fa-microchip text-red-400 text-3xl"></i>,
      title: "IoT Modules",
      description: "Get hands-on with Internet of Things and embedded systems.",
    },
    {
      icon: <i className="fas fa-brain text-indigo-400 text-3xl"></i>,
      title: "AI Bootcamps",
      description:
        "Explore machine learning, data, and neural networks early on.",
    },
  ];

  return (
    <section className="bg-gradient-to-br from-blue-500 to-purple-700 text-white pb-28">
      {/* Hero Text Section */}
      <div className="container mx-auto px-4 text-center pt-24">
        <h1 className="text-5xl md:text-7xl font-extrabold leading-tight animate-fade-in">
          Unlock Your Learning Journey
        </h1>
        <h2 className="text-4xl md:text-6xl font-bold text-yellow-300 mt-4 animate-pulse">
          <span className="inline-block animate-float-subtle">
            with Tinker Tutor
          </span>
        </h2>
        <p className="text-xl md:text-2xl max-w-3xl mx-auto mt-6 animate-fade-in-delay opacity-80">
          Personalized learning for students of Classes 5-12. Build strong
          concepts, track your growth, and explore future tech like Robotics,
          IoT, and AI.
        </p>
        <Link
          href="/dashboard"
          className="inline-block mt-10 px-10 py-4 bg-white text-blue-600 font-semibold rounded-full shadow-lg hover:bg-blue-100 transition-transform duration-300 transform hover:scale-105 animate-bounce-subtle"
        >
          Start Learning
        </Link>
      </div>

      {/* Feature Cards Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-20 max-w-6xl mx-auto px-4">
        {features.map((feature, index) => (
          <div
            key={index}
            className="opacity-0 animate-slide-up"
            style={{
              animationDelay: `${0.3 + index * 0.2}s`,
              animationFillMode: "forwards",
              animationDuration: "0.8s",
            }}
          >
            <FeatureCard
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          
          </div>
        ))}
      </div>

      {/* Future Tech Carousel */}
      <div className="mt-24 px-4 max-w-5xl mx-auto">
        <h3 className="text-3xl font-bold text-center mb-8">
          Explore Future Technologies
        </h3>
        <div className="flex overflow-x-auto gap-6 pb-4 hide-scroll-bar snap-x snap-mandatory">
          {["AI", "IoT", "Robotics", "Coding", "3D Printing"].map(
            (topic, idx) => (
              <div
                key={idx}
                className="min-w-[250px] bg-white/10 backdrop-blur-md rounded-xl p-6 text-center snap-start shadow-lg"
              >
                <div className="text-5xl mb-4">
                  {topic === "AI" && (
                    <i className="fas fa-brain text-pink-400" />
                  )}
                  {topic === "IoT" && (
                    <i className="fas fa-microchip text-teal-300" />
                  )}
                  {topic === "Robotics" && (
                    <i className="fas fa-robot text-indigo-300" />
                  )}
                  {topic === "Coding" && (
                    <i className="fas fa-code text-green-300" />
                  )}
                  {topic === "3D Printing" && (
                    <i className="fas fa-cube text-orange-300" />
                  )}
                </div>
                <h4 className="text-xl font-semibold mb-2">{topic}</h4>
                <p className="text-sm opacity-80">
                  Dive into {topic} projects, bootcamps, and interactive
                  modules.
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
