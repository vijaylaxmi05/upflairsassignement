import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/lib/utils";
import { ArrowLeft, ArrowRight, Flag } from "lucide-react";
import {
  Clock,
  Pause,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  Send,
} from "lucide-react";
import QuizNavigator from "@/components/quizNavigator.jsx";
import { API_BASE_URL } from "../config";

export default function QuizInterface() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [quizData, setQuizData] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("currentQuiz");
    if (!stored) {
      navigate("/student");
      return;
    }
    const data = JSON.parse(stored);
    const questions = data.questions.map((q, idx) => ({
      id: q.id || `qid-${idx}`,
      ...structuredClone(q),
      options: q.options.map((opt, i) =>
        typeof opt === "string"
          ? { label: String.fromCharCode(65 + i), text: opt }
          : { ...opt }
      ),
    }));
    setQuizData({ ...data, questions });
    setTimeRemaining(
      Math.floor((data.startTime + data.duration - Date.now()) / 1000)
    );
  }, [navigate]);

  useEffect(() => {
    if (!quizData || isPaused || timeRemaining <= 0) return;
    const timer = setInterval(() => {
      setTimeRemaining((prev) =>
        prev <= 1 ? (handleSubmitQuiz(), 0) : prev - 1
      );
    }, 1000);
    return () => clearInterval(timer);
  }, [quizData, isPaused, timeRemaining]);

  const handleAnswerSelect = (questionId, selectedAnswer) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        ...prev[questionId],
        questionId,
        selectedAnswer,
        isMarkedForReview: prev[questionId]?.isMarkedForReview || false,
      },
    }));
  };

  const handleMarkForReview = () => {
    if (!quizData) return;
    const id = quizData.questions[currentQuestionIndex].id;
    setAnswers((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        questionId: id,
        selectedAnswer: prev[id]?.selectedAnswer || "",
        isMarkedForReview: !prev[id]?.isMarkedForReview,
      },
    }));
  };

  const handleSubmitQuiz = async () => {
    if (!quizData) return;
    const quizAnswers = quizData.questions.map((q) => {
      const ans = answers[q.id] || {};
      const selectedIndex = ans.selectedAnswer
        ? ans.selectedAnswer.charCodeAt(0) - 65
        : -1;
      const correctIndex = q.correctAnswerIndex;
      return {
        questionId: q._id,
        selectedIndex,
        correctIndex,
        selectedLabel: ans.selectedAnswer || "",
        correctLabel:
          typeof correctIndex === "number"
            ? String.fromCharCode(65 + correctIndex)
            : "",
        correctText: q.options?.[correctIndex]?.text || "",
      };
    });

    const correctCount = quizAnswers.filter(
      (q) => q.selectedIndex === q.correctIndex
    ).length;
    const score = Math.round((correctCount / quizData.questions.length) * 100);
    const timeSpent = Math.floor(
      (quizData.duration - timeRemaining * 1000) / 1000
    );
    const quizResult = {
      student: JSON.parse(localStorage.getItem("user"))?._id,
      questions: quizAnswers,
      score,
      timeTaken: timeSpent,
      class: Number(quizData.config.class),
      stream:
        Number(quizData.config.class) < 11 || quizData.config.stream === "None"
          ? null
          : quizData.config.stream,
      subject: quizData.config.subject,
      topic: quizData.config.topic || null,
    };

    try {
      await fetch(`${API_BASE_URL}/submissions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(quizResult),
      });
      localStorage.setItem(
        "quizResults",
        JSON.stringify({
          ...quizResult,
          questions: quizData.questions,
          userAnswers: answers,
        })
      );
      localStorage.removeItem("currentQuiz");
      navigate("/results");
    } catch {
      toast({
        title: "Error",
        description: "Failed to submit quiz. Please try again.",
        variant: "destructive",
      });
    }
  };

  const goToQuestion = (i) => setCurrentQuestionIndex(i);
  const nextQuestion = () =>
    currentQuestionIndex < quizData?.questions?.length - 1 &&
    setCurrentQuestionIndex(currentQuestionIndex + 1);
  const previousQuestion = () =>
    currentQuestionIndex > 0 &&
    setCurrentQuestionIndex(currentQuestionIndex - 1);

  if (!quizData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Loading quiz...</p>
      </div>
    );
  }

  const current = quizData.questions[currentQuestionIndex];
  const progress =
    ((currentQuestionIndex + 1) / (quizData.questions.length || 1)) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col lg:flex-row gap-6">
        {/* Main Quiz Panel */}
        <div className="flex-1">
          <Card className="overflow-hidden">
            {/* Header */}
            <div className="px-6 py-4 bg-blue-50 border-b border-blue-200">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-blue-900">
                    {quizData.config.subject} Quiz
                  </h3>
                  <p className="text-sm text-blue-700">
                    Question {currentQuestionIndex + 1} of{" "}
                    {quizData.questions.length}
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <div className="bg-white rounded-lg px-4 py-2 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <Clock
                        className={`w-5 h-5 ${
                          timeRemaining < 300
                            ? "text-red-500"
                            : "text-orange-500"
                        }`}
                      />
                      <span
                        className={`font-mono text-lg font-semibold ${
                          timeRemaining < 300 ? "text-red-900" : "text-gray-900"
                        }`}
                      >
                        {formatTime(timeRemaining)}
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    onClick={() => setIsPaused(!isPaused)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    {isPaused ? "Resume" : "Pause"}
                  </Button>
                </div>
              </div>
              <div className="mt-4">
                <Progress value={progress} className="w-full h-2" />
              </div>
            </div>

            {/* Question Body */}
            <div className="p-6 sm:p-8">
              <div className="mb-8">
                <h4 className="text-xl font-medium text-gray-900 mb-4">
                  {current.questionText}
                </h4>
                <p className="text-gray-600 text-sm mb-6">
                  Select the correct answer from the options below:
                </p>
              </div>
              <div className="space-y-4">
                {current.options.map((opt) => (
                  <label
                    key={`${current.id}-${opt.label}`}
                    className={`flex items-start p-4 border-2 rounded-lg cursor-pointer transition-colors duration-200 ${
                      answers[current.id]?.selectedAnswer === opt.label
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                    }`}
                  >
                    <input
                      type="radio"
                      name={`q-${current.id}`}
                      value={opt.label}
                      checked={
                        answers[current.id]?.selectedAnswer === opt.label
                      }
                      onChange={(e) =>
                        handleAnswerSelect(current.id, e.target.value)
                      }
                      className="mt-1 mr-4 text-blue-500 focus:ring-blue-500"
                    />
                    <span className="flex-1">
                      <div className="flex items-center">
                        <span className="inline-flex items-center justify-center w-6 h-6 bg-gray-100 text-gray-700 text-sm font-medium rounded-full mr-3">
                          {opt.label}
                        </span>
                        <span className="text-gray-900">{opt.text}</span>
                      </div>
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="px-4 py-4 sm:px-8 bg-gray-50 border-t border-gray-200">
              <div className="flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-4 mt-4">
                {/* Previous */}
                <Button
                  onClick={previousQuestion}
                  className="w-full sm:w-auto bg-gray-200 text-black hover:bg-gray-300 flex items-center justify-center gap-2"
                  disabled={currentQuestionIndex === 0}
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="hidden lg:inline">Previous</span>
                </Button>

                {/* Mark for Review */}
                <Button
                  onClick={handleMarkForReview}
                  className="w-full sm:w-auto bg-yellow-100 text-yellow-800 hover:bg-yellow-200 flex items-center justify-center gap-2"
                >
                  <Flag className="w-4 h-4" />
                  <span className="hidden lg:inline">
                    {answers[current.id]?.isMarkedForReview
                      ? "Unmark Review"
                      : "Mark for Review"}
                  </span>
                </Button>

                {/* Next */}
                <Button
                  onClick={nextQuestion}
                  className="w-full sm:w-auto bg-blue-500 text-white hover:bg-blue-600 flex items-center justify-center gap-2"
                  disabled={
                    currentQuestionIndex === quizData.questions.length - 1
                  }
                >
                  <span className="hidden lg:inline">Next</span>
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigator Panel */}
        <div className="hidden lg:block w-full lg:w-64">
          <QuizNavigator
            questions={quizData.questions}
            answers={answers}
            currentQuestionIndex={currentQuestionIndex}
            onQuestionSelect={goToQuestion}
            onSubmitQuiz={handleSubmitQuiz}
            isMobile={false}
          />
        </div>

        <div className="block lg:hidden w-full">
          <QuizNavigator
            questions={quizData.questions}
            answers={answers}
            currentQuestionIndex={currentQuestionIndex}
            onQuestionSelect={goToQuestion}
            onSubmitQuiz={handleSubmitQuiz}
            isMobile={true}
          />
        </div>
      </div>
    </div>
  );
}
