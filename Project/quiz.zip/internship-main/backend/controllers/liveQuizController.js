import Question from "../models/Question.js"
import LiveQuizSession from "../models/LiveQuizSession.js"
import { generateMCQs } from "../utils/generateQuestion.js"

// Create a new live quiz session
export const createLiveQuizSession = async (req, res) => {
  try {
    const {
      title,
      class: classLevel,
      stream = "None",
      subject,
      topic = "",
      questionCount = 10,
      duration = 15,
    } = req.body

    const adminId = req.admin._id
    const parsedClass = Number.parseInt(classLevel)
    const parsedQuestionCount = Number.parseInt(questionCount)

    // Generate quiz questions
    const filter = {
      class: parsedClass,
      subject,
    }
    if (parsedClass >= 11 && stream !== "None") filter.stream = stream
    if (topic) filter.topic = topic

    let existingQuestions = await Question.find(filter).lean()

    // If not enough questions exist, generate with AI
    if (existingQuestions.length < parsedQuestionCount) {
      const remaining = parsedQuestionCount - existingQuestions.length
      try {
        const generated = await generateMCQs({
          classLevel: parsedClass,
          stream,
          subject,
          topic,
        })

        const formatted = generated
          .slice(0, remaining)
          .filter((q) => q.options?.length === 4 && q.correctAnswerIndex >= 0)
          .map((q) => ({
            class: parsedClass,
            stream,
            subject,
            topic: topic || "General",
            questionText: q.questionText,
            options: q.options,
            correctAnswerIndex: q.correctAnswerIndex,
          }))

        if (formatted.length > 0) {
          const inserted = await Question.insertMany(formatted)
          existingQuestions = [...existingQuestions, ...inserted]
        }
      } catch (error) {
        console.error("Error generating questions:", error)
      }
    }

    // Select random questions
    const selectedQuestions = existingQuestions.sort(() => 0.5 - Math.random()).slice(0, parsedQuestionCount)

    if (selectedQuestions.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No questions available for the selected criteria",
      })
    }

    // Create live quiz session
    const liveQuizSession = new LiveQuizSession({
      title,
      admin: adminId,
      class: parsedClass,
      stream,
      subject,
      topic,
      questions: selectedQuestions.map((q) => q._id),
      duration: Number.parseInt(duration),
      status: "waiting",
      participants: [],
      currentQuestionIndex: 0,
    })

    await liveQuizSession.save()

    // Generate shareable link
    const shareableLink = `${process.env.USER_FRONTEND_URL || "http://localhost:5173"}/live-quiz/${liveQuizSession._id}`

    res.status(201).json({
      success: true,
      session: {
        _id: liveQuizSession._id,
        title: liveQuizSession.title,
        shareCode: liveQuizSession.shareCode,
        questionCount: selectedQuestions.length,
        status: liveQuizSession.status,
      },
      shareableLink,
      message: "Live quiz session created successfully",
    })
  } catch (error) {
    console.error("Error creating live quiz session:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create live quiz session",
      error: error.message,
    })
  }
}

// Get live quiz session details
export const getLiveQuizSession = async (req, res) => {
  try {
    const { sessionId } = req.params

    const session = await LiveQuizSession.findById(sessionId)
      .populate("questions")
      .populate("admin", "name email")
      .populate("participants.student", "name email")

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Live quiz session not found",
      })
    }

    res.json({
      success: true,
      session,
    })
  } catch (error) {
    console.error("Error fetching live quiz session:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch live quiz session",
    })
  }
}

// Get admin's live quiz sessions
export const getAdminLiveQuizSessions = async (req, res) => {
  try {
    const adminId = req.admin._id

    const sessions = await LiveQuizSession.find({ admin: adminId })
      .sort({ createdAt: -1 })
      .populate("participants.student", "name email")

    res.json({
      success: true,
      sessions,
    })
  } catch (error) {
    console.error("Error fetching admin live quiz sessions:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch live quiz sessions",
    })
  }
}

// Delete live quiz session
export const deleteLiveQuizSession = async (req, res) => {
  try {
    const { sessionId } = req.params
    const adminId = req.admin._id

    const session = await LiveQuizSession.findOne({
      _id: sessionId,
      admin: adminId,
    })

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found or unauthorized",
      })
    }

    await LiveQuizSession.findByIdAndDelete(sessionId)

    res.json({
      success: true,
      message: "Session deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting session:", error)
    res.status(500).json({
      success: false,
      message: "Failed to delete session",
    })
  }
}
