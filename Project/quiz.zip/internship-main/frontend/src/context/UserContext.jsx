import { createContext, useState, useContext, useEffect } from 'react';

const BASE_URL = 'https://tinker-tutor.onrender.com/api/auth';
// const BASE_URL = 'https://quiz-app-tinkd.onrender.com/api/auth';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [userData, setUserData] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // On mount, try restoring user from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('token');

    if (storedUser && token) {
      try {
        setUserData(JSON.parse(storedUser));
        setIsAuthenticated(true);
      } catch (err) {
        console.error('Failed to parse user data:', err);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      }
    }
  }, []);

  const signIn = async (email, password) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`${BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || 'Login failed');
      }

      const data = await res.json();
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));

      setUserData(data.user);
      setIsAuthenticated(true);
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const signUp = async (userDetails) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`${BASE_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userDetails)
      });
      console.log(res)

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || 'Sign up failed');
      }

      const data = await res.json();
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));

      setUserData(data.user);
      setIsAuthenticated(true);
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setUserData(null);
    setIsAuthenticated(false);
  };

  const updateUserData = async (updates) => {
    const token = localStorage.getItem('token');
    if (!token) return false;

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${BASE_URL}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(updates)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || 'Update failed');
      }

      const data = await res.json();
      localStorage.setItem('user', JSON.stringify(data));
      setUserData(data);
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfilePicture = async (imageUrl) => {
    return updateUserData({ profilePicture: imageUrl });
  };

  return (
    <UserContext.Provider value={{
      userData,
      isAuthenticated,
      isLoading,
      error,
      signIn,
      signUp,
      signOut,
      updateUserData,
      updateProfilePicture
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
