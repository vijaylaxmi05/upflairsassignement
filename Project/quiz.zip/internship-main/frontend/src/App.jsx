import React from "react";
import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import Toaster from "./components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AdminLayout from "./layout/AdminLayout";
import { AdminProvider } from "./context/AdminContext";
import { UserProvider } from "./context/UserContext";

// Page Imports
import LandingPage from "@/pages/LandingPage";
import HomePage from "@/pages/HomePage";
import AuthChoice from "@/pages/AuthChoice";
import SignIn from "@/pages/SignIn";
import SignUp from "@/pages/SignUp";
import Dashboard from "@/pages/Dashboard";
import Profile from "@/pages/Profile";
import TakeQuiz from "@/pages/TakeQuiz";
import QuizInterface from "@/pages/QuizInterface";
import QuizResults from "@/pages/QuizResults";
import Reports from "@/pages/Reports";
import StudentPortal from "@/pages/StudentPortal";
import NotFound from "@/pages/NotFound";

import AdminLogin from "@/pages/AdminLogin";
import AdminRegister from "@/pages/AdminRegister";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminProfile from "@/pages/AdminProfile";
import LiveQuizManagement from "@/pages/LiveQuizManagement";
import LiveQuizMonitor from "@/pages/LiveQuizMonitor";
import StudentPerformancePanel from "@/components/StudentPerformancePanel";

function AppRoutes() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={HomePage} />
      {/* <Route path="/auth" component={AuthChoice} /> */}
      <Route path="/select-role" component={AuthChoice} />
      <Route path="/signin" component={SignIn} />
      <Route path="/signup" component={SignUp} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/profile" component={Profile} />
      <Route path="/quiz" component={TakeQuiz} />
      <Route path="/quiz-interface" component={QuizInterface} />
      <Route path="/results" component={QuizResults} />
      <Route path="/reports" component={Reports} />
  
      {/* <Route path="/student-stats" component={StudentPortal} /> */}

      {/* Admin Auth Routes */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/register" component={AdminRegister} />

      {/* Admin Routes (with layout) */}
      <Route path="/admin/dashboard">
        <AdminLayout>
          <AdminDashboard />
        </AdminLayout>
      </Route>

      <Route path="/admin/profile">
        <AdminLayout>
          <AdminProfile />
        </AdminLayout>
      </Route>

      <Route path="/admin/live-quiz">
        <AdminLayout>
          <LiveQuizManagement />
        </AdminLayout>
      </Route>

      <Route path="/admin/live-quiz-monitor/:sessionId">
        <AdminLayout>
          <LiveQuizMonitor />
        </AdminLayout>
      </Route>

      
      <Route path="/admin/student-stats">
        <AdminLayout>
          <StudentPerformancePanel />
        </AdminLayout>
      </Route>

      {/* 404 fallback */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AdminProvider>
          <UserProvider>
            <Toaster />
            <AppRoutes />
          </UserProvider>
        </AdminProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
