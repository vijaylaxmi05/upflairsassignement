Tinker Tutor - Quiz Website Internship Project Plan
Project Title: Full-Stack Quiz Platform for Classes 5-12 (PCM/PCB Focused)
Duration: 45 Days
Project Overview:
Build a full-stack quiz web application for students from grades 5 to 12. The system should
support class-wise and subject-wise (PCM/PCB) quizzes, user authentication, quiz-taking
functionality, and detailed report cards for performance tracking.
 Intern Role Distribution:
Rashi Daga: Authentication & User Management
Responsibilities:
• Implement user login and registration system
• Build user profiles with class, name, stream (PCM/PCB), and email
• Optional: Implement password reset flow
Kanika : Quiz System & Question Management
Responsibilities:
• Create admin panel for adding/editing/deleting quiz questions
• Allow students to select class and topic to start quizzes
• Randomize question and answer order
• Implement quiz timer
Hitesh Kumar: Report Card & Result System
Responsibilities:
• Generate report card after each quiz (score, correct, wrong, percentage)
• Show review of correct answers
• Create "My Report Card" page listing past quizzes and performance
• Store results in DB with timestamps
Prantik: UI/UX Design & Dashboard Integration
Responsibilities:
• Design and implement the frontend with clean, responsive UI
• Build student dashboard with profile, quiz access, and reports
• Coordinate module integration with other interns
• Ensure cross-platform and mobile compatibility
