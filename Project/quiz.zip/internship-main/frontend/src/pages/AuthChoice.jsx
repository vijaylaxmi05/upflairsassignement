import { Link } from 'wouter';

const AuthChoice = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-500 px-4">
      <div className="max-w-5xl w-full bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl p-10 md:p-16 text-white animate-fade-in">

        {/* Heading */}
        <h1 className="text-4xl md:text-5xl font-extrabold text-center text-white mb-4 drop-shadow-lg">
          Welcome to <span className="text-yellow-300">Tinker Tutor</span>
        </h1>
        <p className="text-lg md:text-xl text-center text-white text-opacity-80 max-w-2xl mx-auto mb-12">
          Choose your path: whether you're here to explore as a student or to mentor as a teacher.
        </p>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">

          {/* Teacher */}
          <Link
            href="/admin/login"
            className="group relative p-8 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl backdrop-blur-xl shadow-lg transform transition-all duration-300 hover:scale-105 hover:shadow-2xl flex flex-col items-center text-center"
          >
            <div className="absolute -top-4 -right-4 w-10 h-10 rounded-full bg-yellow-300/20 group-hover:animate-ping"></div>
            <div className="text-6xl mb-4 text-yellow-300 transition-transform duration-300 group-hover:scale-110">
              <i className="fas fa-chalkboard-teacher"></i>
            </div>
            <h2 className="text-2xl font-bold mb-2 text-white">I'm a Teacher</h2>
            <p className="text-white text-opacity-80">
              Manage lessons, track student progress, and share your expertise with ease.
            </p>
          </Link>

          {/* Student */}
          <Link
            href="/signin"
            className="group relative p-8 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl backdrop-blur-xl shadow-lg transform transition-all duration-300 hover:scale-105 hover:shadow-2xl flex flex-col items-center text-center"
          >
            <div className="absolute -top-4 -left-4 w-10 h-10 rounded-full bg-green-300/20 group-hover:animate-ping"></div>
            <div className="text-6xl mb-4 text-green-300 transition-transform duration-300 group-hover:scale-110">
              <i className="fas fa-user-graduate"></i>
            </div>
            <h2 className="text-2xl font-bold mb-2 text-white">I'm a Student</h2>
            <p className="text-white text-opacity-80">
              Access interactive lessons, take quizzes, and monitor your progress.
            </p>
          </Link>

        </div>
      </div>
    </div>
  );
};

export default AuthChoice;
